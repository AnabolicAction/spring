package com.hw.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.hw.frame.Biz;
import com.hw.vo.Product;
import com.hw.vo.User;

@Controller
public class ProductController {
	@Resource(name="userBiz")
	Biz<Product,Integer> biz;
		
	@ModelAttribute("productadd.hw")
	public String add(){
		return "product/add";
	}
	
	@ModelAttribute("productaddimpl.hw")
	public String addimpl(Product p){
		
		return "product/detail";
	}
	
	
	
	
}





